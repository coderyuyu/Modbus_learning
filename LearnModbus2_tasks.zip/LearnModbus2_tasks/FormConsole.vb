﻿Public Class FormConsole

End Class